package com.erpambudi.moviecatalogue.room;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.erpambudi.moviecatalogue.model.TvShow;

import java.util.List;

@Dao
public interface TvShowDao {

    @Query("Select * from tvshow")
    List<TvShow> getAll();

    @Insert
    void  insertTvShow(TvShow tvShow);

    @Delete
    void deleteTvShow(TvShow tvShow);
}
