package com.erpambudi.moviecatalogue.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TvShowItems {

    @SerializedName("results")
    private List<TvShow> listTvShow;

    public List<TvShow> getListTvShow() {
        return listTvShow;
    }

    public void setListTvShow(List<TvShow> listTvShow) {
        this.listTvShow = listTvShow;
    }
}
