package com.erpambudi.moviecatalogue.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TvShowDetail implements Parcelable {

    @SerializedName("id")
    private int id;
    @SerializedName("name")
    private String name;
    @SerializedName("poster_path")
    private String poster;
    @SerializedName("overview")
    private String overview;
    @SerializedName("number_of_episodes")
    private int episode;
    @SerializedName("number_of_seasons")
    private int seasons;
    @SerializedName("vote_average")
    private double voteAverage;
    @SerializedName("genres")
    private List<Genres> genres;

    protected TvShowDetail(Parcel in) {
        id = in.readInt();
        name = in.readString();
        poster = in.readString();
        overview = in.readString();
        episode = in.readInt();
        seasons = in.readInt();
    }

    public TvShowDetail() {
    }

    public static final Creator<TvShowDetail> CREATOR = new Creator<TvShowDetail>() {
        @Override
        public TvShowDetail createFromParcel(Parcel in) {
            return new TvShowDetail(in);
        }

        @Override
        public TvShowDetail[] newArray(int size) {
            return new TvShowDetail[size];
        }
    };

    public double getVoteAverage() {
        return voteAverage;
    }

    public void setVoteAverage(double voteAverage) {
        this.voteAverage = voteAverage;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public int getEpisode() {
        return episode;
    }

    public void setEpisode(int episode) {
        this.episode = episode;
    }

    public int getSeasons() {
        return seasons;
    }

    public void setSeasons(int seasons) {
        this.seasons = seasons;
    }

    public List<Genres> getGenres() {
        return genres;
    }

    public void setGenres(List<Genres> genres) {
        this.genres = genres;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeString(poster);
        parcel.writeString(overview);
        parcel.writeInt(episode);
        parcel.writeInt(seasons);
    }

    public class Genres{
        @SerializedName("name")
        String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

}
