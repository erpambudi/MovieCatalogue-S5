package com.erpambudi.moviecatalogue.ui.favorite;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.erpambudi.moviecatalogue.R;
import com.erpambudi.moviecatalogue.adapter.FavoriteTvShowAdapter;
import com.erpambudi.moviecatalogue.model.TvShow;
import com.erpambudi.moviecatalogue.room.AppDatabaseTvShow;

import java.util.ArrayList;
import java.util.List;
import static com.erpambudi.moviecatalogue.room.MyApp.dbTvShow;

/**
 * A simple {@link Fragment} subclass.
 */
public class TvShowFavoriteFragment extends Fragment {

    public static final String TVSHOW_KEY = "tvshow_key";
    private RecyclerView rvTvShow;
    private List<TvShow> list;
    private FavoriteTvShowAdapter tvShowAdapter;
    private ProgressBar progressBar;

    public TvShowFavoriteFragment() {
        // Required empty public constructor
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_tv_show_favorite, container, false);

        rvTvShow = root.findViewById(R.id.rv_film);
        rvTvShow.setHasFixedSize(true);
        progressBar = root.findViewById(R.id.progressBar);

        showRecyclerList();

        if (savedInstanceState == null){
            getTvShow(getActivity());
        }else {
            onActivityCreated(savedInstanceState);
        }
        return root;
    }

    private void showRecyclerList() {
        rvTvShow.setLayoutManager(new LinearLayoutManager(getActivity()));
        tvShowAdapter = new FavoriteTvShowAdapter(getActivity());
    }

    private void getTvShow(Context context) {
        showLoading(true);
        dbTvShow = Room.databaseBuilder(context,
                AppDatabaseTvShow.class, "tvshow").allowMainThreadQueries().build();
        list = dbTvShow.tvShowDao().getAll();

        tvShowAdapter.setListTvShow(list);
        rvTvShow.setAdapter(tvShowAdapter);
        showLoading(false);

    }

    private void showLoading(Boolean state){
        if (state){
            progressBar.setVisibility(View.VISIBLE);
        }else{
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(TVSHOW_KEY, new ArrayList<>(tvShowAdapter.getListTvShow()));
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null){
            List<TvShow> list;
            list = savedInstanceState.getParcelableArrayList(TVSHOW_KEY);
            tvShowAdapter.setListTvShow(list);
            rvTvShow.setAdapter(tvShowAdapter);
        }
    }

}
