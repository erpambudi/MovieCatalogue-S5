package com.erpambudi.moviecatalogue.room;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.erpambudi.moviecatalogue.model.TvShow;

@Database(entities = {TvShow.class}, version = 1, exportSchema = false)
public abstract class AppDatabaseTvShow extends RoomDatabase {
    public abstract TvShowDao tvShowDao();
}
