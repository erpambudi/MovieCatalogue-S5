package com.erpambudi.moviecatalogue.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.erpambudi.moviecatalogue.BuildConfig;
import com.erpambudi.moviecatalogue.R;
import com.erpambudi.moviecatalogue.model.TvShow;
import com.erpambudi.moviecatalogue.ui.tvshow.DetailTvshowActivity;

import java.util.List;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder> {

    private List<TvShow> listTvShow;
    private Context context;

    public List<TvShow> getListTvShow() {
        return listTvShow;
    }

    public TvShowAdapter(Context context) {
        this.context = context;
    }

    public void setListTvShow(List<TvShow> listTvShow) {
        this.listTvShow = listTvShow;
    }

    @NonNull
    @Override
    public TvShowViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_tv_show, viewGroup, false);
        return new TvShowAdapter.TvShowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TvShowViewHolder holder, final int position) {
        String txt = "";
        TvShow tvShow = listTvShow.get(position);

        holder.tvNameTvShow.setText(tvShow.getName());
        holder.tvVoteAverage.setText(String.valueOf(tvShow.getVoteAverage()));
        Glide.with(context)
                .load(BuildConfig.POSTER_PATH + tvShow.getPoster())
                .into(holder.imgPhotoTvShow);

        holder.cvItemTvShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailTvshowActivity.class);
                intent.putExtra(DetailTvshowActivity.EXTRA_TV_SHOW, listTvShow.get(position));
                context.startActivity(intent);
            }
        });

        if (tvShow.getOverview().equals(txt)){
            holder.tvOverviewTvShow.setText(context.getResources().getString(R.string.overview_nothing));
        }else {
            holder.tvOverviewTvShow.setText(tvShow.getOverview());
        }

    }

    @Override
    public int getItemCount() {
        return listTvShow.size();
    }

    class TvShowViewHolder extends RecyclerView.ViewHolder {

        TextView tvNameTvShow;
        TextView tvOverviewTvShow;
        ImageView imgPhotoTvShow;
        TextView tvVoteAverage;
        CardView cvItemTvShow;

        TvShowViewHolder(View itemView) {
            super(itemView);
            tvNameTvShow = itemView.findViewById(R.id.tv_name_tv_show);
            tvOverviewTvShow = itemView.findViewById(R.id.tv_overview_tv_show);
            imgPhotoTvShow = itemView.findViewById(R.id.img_photo_tv_show);
            tvVoteAverage = itemView.findViewById(R.id.tv_vote_average);
            cvItemTvShow = itemView.findViewById(R.id.cv_item_tv_show);
        }
    }
}
