package com.erpambudi.moviecatalogue.room;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.erpambudi.moviecatalogue.model.Movies;

import java.util.List;

@Dao
public interface MovieDao {

    @Query("Select * from movies")
    List<Movies> getAll();

    @Insert
    void  insertMovie(Movies movies);

    @Delete
    void deleteMovie(Movies movies);

}
