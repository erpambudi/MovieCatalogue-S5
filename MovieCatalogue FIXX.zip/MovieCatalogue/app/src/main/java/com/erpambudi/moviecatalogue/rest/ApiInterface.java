package com.erpambudi.moviecatalogue.rest;

import com.erpambudi.moviecatalogue.model.MoviesDetail;
import com.erpambudi.moviecatalogue.model.MoviesItems;
import com.erpambudi.moviecatalogue.model.TvShowDetail;
import com.erpambudi.moviecatalogue.model.TvShowItems;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("discover/movie")
    Call<MoviesItems> getDiscoverMovie(@Query("api_key") String apiKey, @Query("language") String language);

    @GET("movie/{id}")
    Call<MoviesDetail> getDetailMovie(@Path("id") int idMovie, @Query("api_key") String apiKey, @Query("language") String language);

    @GET("discover/tv")
    Call<TvShowItems> getDiscoverTvShow(@Query("api_key") String apiKey, @Query("language") String language);

    @GET("tv/{id}")
    Call<TvShowDetail> getDetailTvShow(@Path("id") int idTvShow, @Query("api_key") String apiKey, @Query("language") String language);

}
