package com.erpambudi.moviecatalogue.ui.tvshow;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.erpambudi.moviecatalogue.BuildConfig;
import com.erpambudi.moviecatalogue.MainActivity;
import com.erpambudi.moviecatalogue.R;
import com.erpambudi.moviecatalogue.model.TvShow;
import com.erpambudi.moviecatalogue.model.TvShowDetail;
import com.erpambudi.moviecatalogue.rest.ApiClient;
import com.erpambudi.moviecatalogue.rest.ApiInterface;
import com.erpambudi.moviecatalogue.room.AppDatabaseTvShow;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.erpambudi.moviecatalogue.room.MyApp.dbTvShow;

public class DetailTvshowActivity extends AppCompatActivity {

    public static final String EXTRA_TV_SHOW = "extra_tv_show";
    ImageView ivTvShow;
    TextView tvNama, tvOverview, tvEpisodes, tvSeasons, tvGenres, tvRating;
    private TvShowDetail tvShowDetail;
    private ProgressBar progressBar;
    public int id;
    private ApiInterface apiServise = ApiClient.getClient().create(ApiInterface.class);
    TvShowDetail detail;
    int love;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tvshow);

        ivTvShow = findViewById(R.id.iv_img_film);
        tvNama = findViewById(R.id.tv_name);
        tvEpisodes = findViewById(R.id.tv_episode);
        tvSeasons = findViewById(R.id.tv_season);
        tvRating = findViewById(R.id.tv_rating);
        tvGenres = findViewById(R.id.tv_genre);
        tvOverview = findViewById(R.id.tv_overview);
        progressBar = findViewById(R.id.progressBar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(getResources().getString(R.string.detail));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        TvShow tvShow = getIntent().getParcelableExtra(EXTRA_TV_SHOW);
        id = tvShow.getId();
        fetchData(id);
        if (savedInstanceState == null){
            getTvShow();
        }else{
            onRestoreInstanceState(savedInstanceState);
        }

    }

    private void getTvShow() {
        showLoading(true);
        Call<TvShowDetail> call = apiServise.getDetailTvShow(id, BuildConfig.API_KEY, this.getResources().getString(R.string.language));
        call.enqueue(new Callback<TvShowDetail>() {
            @Override
            public void onResponse(Call<TvShowDetail> call, Response<TvShowDetail> response) {
                if (response.body()!=null){
                    tvShowDetail = response.body();
                }
                setData(tvShowDetail);
                showLoading(false);
            }

            @Override
            public void onFailure(Call<TvShowDetail> call, Throwable t) {
                Toast.makeText(DetailTvshowActivity.this, getResources().getString(R.string.no_data), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setData(TvShowDetail data){
        detail = data;
        String txt = "";
        String photo = data.getPoster();
        String name = data.getName();
        int episodes = data.getEpisode();
        int seasons = data.getSeasons();
        double rating = data.getVoteAverage();
        String overview = data.getOverview();
        StringBuilder genre = new StringBuilder();
        for (int i = 0; i <data.getGenres().size() ; i++) {
            genre.append(data.getGenres().get(i).getName()).append(" ");
        }

        if (data.getOverview().equals(txt)){
            tvOverview.setText(this.getResources().getString(R.string.overview_nothing));
        }else {
            tvOverview.setText(overview);
        }

        Glide.with(this).load(BuildConfig.POSTER_PATH + photo).into(ivTvShow);
        tvNama.setText(name);
        tvEpisodes.setText(String.valueOf(episodes));
        tvSeasons.setText(String.valueOf(seasons));
        tvGenres.setText(genre.toString());
        tvRating.setText(String.valueOf(rating));
    }

    private void showLoading(Boolean state){
        if (state){
            progressBar.setVisibility(View.VISIBLE);
        }else{
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        Log.d("DetailMovieActivity","onSaveInstanceState detail data: "+detail.getPoster());
        super.onSaveInstanceState(outState);
        outState.putParcelable(EXTRA_TV_SHOW, detail);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        Log.d("DetailMovieActivity","onRestoreInstanceState: running");
        super.onRestoreInstanceState(savedInstanceState);
        TvShowDetail detail;
        detail = savedInstanceState.getParcelable(EXTRA_TV_SHOW);
        setData(detail);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.favorite_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem menuItem = menu.findItem(R.id.menu_no_favorite);
        if (love == 1){
            menuItem.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_favorite_white_24dp));
        }else{
            menuItem.setIcon(ContextCompat.getDrawable(this, R.drawable.ic_favorite_border_white_24dp));
        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        int getId = item.getItemId();

        if (getId == R.id.menu_no_favorite) {
            TvShow tvShow = new TvShow(detail.getId(), detail.getName(), detail.getPoster(), detail.getOverview(), detail.getVoteAverage());
            if (love == 0) {
                item.setIcon(R.drawable.ic_favorite_white_24dp);
                dbTvShow.tvShowDao().insertTvShow(tvShow);
                love = 1;
                Toast.makeText(DetailTvshowActivity.this, getResources().getString(R.string.add_favorite), Toast.LENGTH_SHORT).show();
            } else {
                item.setIcon(R.drawable.ic_favorite_border_white_24dp);
                dbTvShow.tvShowDao().deleteTvShow(tvShow);
                love = 0;
                Toast.makeText(DetailTvshowActivity.this, getResources().getString(R.string.remove_favorite), Toast.LENGTH_SHORT).show();
            }
        }
        if (getId == android.R.id.home){
            onBackPressed();
        }

        return super.onOptionsItemSelected(item);
    }

    public void fetchData(int id){
        dbTvShow = Room.databaseBuilder(this,
                AppDatabaseTvShow.class, "tvshow").allowMainThreadQueries().build();

        List<TvShow> list = dbTvShow.tvShowDao().getAll();

        for (int i = 0; i < list.size() ; i++) {
            if (list.get(i).getId() == id){
                love = 1;
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivityForResult(new Intent(DetailTvshowActivity.this, MainActivity.class), 200);
    }

}
