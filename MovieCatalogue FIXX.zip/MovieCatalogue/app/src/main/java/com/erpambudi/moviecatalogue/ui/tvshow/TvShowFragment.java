package com.erpambudi.moviecatalogue.ui.tvshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.erpambudi.moviecatalogue.BuildConfig;
import com.erpambudi.moviecatalogue.R;
import com.erpambudi.moviecatalogue.adapter.TvShowAdapter;
import com.erpambudi.moviecatalogue.model.TvShow;
import com.erpambudi.moviecatalogue.model.TvShowItems;
import com.erpambudi.moviecatalogue.rest.ApiClient;
import com.erpambudi.moviecatalogue.rest.ApiInterface;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TvShowFragment extends Fragment {

    public static final String TV_SHOW_KEY = "tv_show_key";
    private RecyclerView rvTvSow;
    private List<TvShow> list;
    private TvShowAdapter tvShowAdapter;
    private ProgressBar progressBar;
    private ApiInterface apiServise = ApiClient.getClient().create(ApiInterface.class);

    public TvShowFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_tvshow, container, false);

        rvTvSow = root.findViewById(R.id.rv_tv_show);
        rvTvSow.setHasFixedSize(true);
        progressBar = root.findViewById(R.id.progressBar);

        showRecyclerList();
        if (savedInstanceState == null){
            getDataTvShow();
        }else {
            onActivityCreated(savedInstanceState);
        }
        return root;
    }

    private void showRecyclerList(){
        rvTvSow.setLayoutManager(new LinearLayoutManager(getActivity()));
        tvShowAdapter = new TvShowAdapter(getActivity());
    }

    private void getDataTvShow(){
        showLoading(true);
        Call<TvShowItems> call = apiServise.getDiscoverTvShow(BuildConfig.API_KEY, getActivity().getResources().getString(R.string.language));
        list = new ArrayList<>();
        call.enqueue(new Callback<TvShowItems>() {
            @Override
            public void onResponse(Call<TvShowItems> call, Response<TvShowItems> response) {
                if (response.body() != null){
                    list = response.body().getListTvShow();
                }
                tvShowAdapter.setListTvShow(list);
                rvTvSow.setAdapter(tvShowAdapter);
                showLoading(false);
            }

            @Override
            public void onFailure(Call<TvShowItems> call, Throwable t) {
                Toast.makeText(getContext(), "Can't Load Data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showLoading(Boolean state){
        if (state){
            progressBar.setVisibility(View.VISIBLE);
        }else{
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(TV_SHOW_KEY, new ArrayList<>(tvShowAdapter.getListTvShow()));
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState != null){
            ArrayList<TvShow> list;
            list = savedInstanceState.getParcelableArrayList(TV_SHOW_KEY);
            tvShowAdapter.setListTvShow(list);
            rvTvSow.setAdapter(tvShowAdapter);
        }
    }
}